#Write a Python program to drop microseconds from datetime.


import datetime
day = datetime.datetime.today()
print()
print(day)
print()