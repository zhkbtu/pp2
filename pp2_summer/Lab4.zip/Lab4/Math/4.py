#Write a Python program to calculate the area of a parallelogram.
#Length of base: 5
#Height of parallelogram: 6
#Expected Output: 30.0


import math

l = int(input("Length of base: "))
h = int(input("Height of parallelogram: "))

print("Expected Output:", l * h)