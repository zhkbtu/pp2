#Implement a generator that returns all numbers from (n) down to 0.


n = int(input())
while n >= 0:
    print(n, end = " ")
    n -= 1