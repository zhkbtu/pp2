import json

with open('sample-data.json') as f:
    data = json.load(f)

header = "Interface Status\n" + "=" * 80 + "\n"
header += "{:<50}{:<25}{:<12}{}\n".format("DN", "Description", "Speed", "MTU")
header += "-" * 80 + "\n"

body = ""
for interface in data["data"]:
    body += "{:<50}{:<25}{:<12}{}\n".format(interface["DN"], interface["Description"], interface["Speed"],
                                           interface["MTU"])

print(header + body)

#Python JSON parsing
#Exercises to parse json data in python

#Exercise 1
#Using data file sample-data.json, create output that resembles the following by parsing the included JSON file.

#Interface Status
#================================================================================
#DN                                                 Description           Speed    MTU  
#-------------------------------------------------- --------------------  ------  ------
#topology/pod-1/node-201/sys/phys-[eth1/33]                              inherit   9150 
#topology/pod-1/node-201/sys/phys-[eth1/34]                              inherit   9150 
#topology/pod-1/node-201/sys/phys-[eth1/35]                              inherit   9150 