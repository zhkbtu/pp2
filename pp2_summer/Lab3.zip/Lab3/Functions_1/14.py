#import function
a=input().strip()
function.f_to_c(a)