#Write a Python program to convert a given camel case string to snake case.

import re

txt = input()
x = re.findall('[A-Z][^A-Z]*', txt)
result = '_'.join(x).lower()
print(result)
