#Write a Python program to find the sequences of one upper case letter followed by lower case letters.

import re

txt = input()
x=re.findall(r'\b[A-Z]{1}[a-z]+\b', txt)

print (x)

