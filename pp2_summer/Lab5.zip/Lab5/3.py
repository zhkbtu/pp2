#Write a Python program to find sequences of lowercase letters joined with a underscore.

import re

txt = input()
matches = re.findall(r'\b[a-z]+_[a-z]+\b', txt)

print("Sequences of lowercase letters joined with an underscore:")
for match in matches:
    print(match)
