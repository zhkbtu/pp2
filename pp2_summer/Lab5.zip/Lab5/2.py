#Write a Python program that matches a string that has an 'a' followed by two to three 'b'.

import re

txt = "abbb"
x = re.findall("a.*b", txt)

print(x)

