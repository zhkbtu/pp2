#Write a python program to convert snake case string to camel case string.

import re
txt = input()
x = re.sub('_', ' ', txt).title()
print(x.replace(" ","")) 


'''import re
txt=input()
x = re.sub("\b[a-z]+_[a-z]+\b", "\b[A-Z]{1}[a-z]\b",txt )

print(x) '''