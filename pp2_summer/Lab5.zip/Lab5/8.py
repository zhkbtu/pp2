#Write a Python program to split a string at uppercase letters.

import re

txt = input() 
x=re.findall('[a-zA-Z][^A-Z]*',txt)

print (x)
